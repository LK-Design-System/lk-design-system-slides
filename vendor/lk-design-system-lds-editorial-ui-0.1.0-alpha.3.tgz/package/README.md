# LDS Editorial

데이터 서사용 LDS 자매 시스템. Core/Theme 토큰을 소비해 **측정 위에 서사를 얹는 층** —
주장 프레임, 주석, 픽토그램 — 의 계약을 소유한다.

**이 층은 매체를 모른다.** 슬라이드·리포트·포스터·웹 아티클은 읽는 거리가 다를 뿐 규약은
같다. 그래서 이 저장소는 순위(value > claim > note > note-body > caption)만 고정하고,
실제 크기는 매체가 정한다 — 아래 [매체 계약](#매체-계약) 참조. 발표 지오메트리(16:9,
세이프존, 투사 스케일)는 별도 도메인인 [LDS Slides](../lk-design-system-slides)가 소유한다.

절차 자체 — 질문 → 주장 → 형태 → 강조 → 검증 — 는 이 저장소의 것이 아니다. 발표 자료·문서·
대시보드 요약에 똑같이 적용되므로 Core가 소유한다: [`docs/EDITORIAL_METHODOLOGY.md`](https://github.com/lk-design-system/lk-design-system/blob/main/docs/EDITORIAL_METHODOLOGY.md).
이 저장소는 그중 **코드로 강제할 수 있는 단계의 집행 장치**를 소유한다 — 컴포넌트, 토큰,
그리고 규약을 검증하는 play 단언.

## 소유 경계

- **Core/Product가 소유**: 측정을 그리는 차트 프리미티브 (`DataBarChart`, `LineChart`,
  `Sparkline`, `Stat` …). 이 저장소는 차트를 다시 만들지 않고 조립한다 — `KeyFigure`의 숫자는
  Product `Stat`이 그린다.
- **LDS Editorial이 소유**: 주석 계약(`AnnotatedFigure`), 픽토그램 수량 표현(`PictogramRow`),
  핵심 수치의 서사 프레임(`KeyFigure`), 옵션 평가의 판정 프레임(`OptionAssessment` — 닫힌
  판정 어휘, 텍스트 병기, 권고 한 열), 목표 대비 실적의 판정 프레임(`StatusAssessment` —
  달성·주의·미달, 색은 이탈만: 달성 배지는 무채색), `--editorial-*` 토큰(강조·주석·단위
  지오메트리·타입 순위).
- **매체가 소유**: 읽는 거리. `--editorial-*-size/line/spacing`을 자기 스코프에서 재지정한다.
- **사용처가 소유**: 어떤 데이터로 무슨 주장을 하는지.

## 표현 규약 (코드가 강제)

- **강조는 한 번에 하나.** 강조 토큰은 하나뿐이고, `AnnotatedFigure`는 여러 주석이 강조를
  요청해도 첫 번째만 승인하고 나머지는 강등한다.
- **그래픽은 보조 채널.** 정확한 값은 항상 텍스트와 접근성 이름으로 병기된다 —
  픽토그램·색만으로 수량을 말하지 않는다.
- **주석은 데이터를 가리지 않는다.** 주석은 도판 위가 아니라 옆에 선다.
- **스케일은 선언한다.** 단위당 값이 1이 아니면 픽토그램은 스케일 범례를 함께 그린다.

규약은 각 스토리의 play 단언이 검증하고, `npm run check:storybook`이 모든 play를
헤드리스 Chromium에서 실행한다. 알려진 실패는 `story-play-known-failures.json`에
고정되며 줄어들 수만 있는 래칫이다 — 현재 `count: 0`.

## 매체 계약

컴포넌트는 업스트림 램프(`--body2-size` 등)를 **직접 참조하지 않는다**. 다섯 단계의
`--editorial-*` 램프만 읽고, 그 기본값이 제품 램프(화면, 팔 길이 거리)를 가리킨다.
매체는 자기 스코프에서 이 다섯 단계를 재지정하면 된다 — 컴포넌트는 건드리지 않는다.

| 단계 | 용도 | 기본값 |
| --- | --- | --- |
| `--editorial-value-*` | 큰 수치 | `--headline1-*` |
| `--editorial-claim-*` | 주장 문장 | `--body2-*` |
| `--editorial-note-*` | 주석 제목 | `--label1-*` |
| `--editorial-note-body-*` | 주석 본문 | `--label2-*` |
| `--editorial-caption-*` | 출처·범례·캡션 | `--caption1-*` |

각 단계는 `-size` `-line` `-spacing` 삼중으로 항상 함께 움직인다. 실례는 Slides의
`tokens/slides.css` 안 `:root [data-lds-slide-surface]` 블록 — 다섯 단계를 투사 스케일로
재지정하며, 그 단언은 Slides의 `ProjectionSeam` 스토리가 소유한다.

## 상태

`0.1.0-alpha.1` — 최소 골격. Storybook 포트는 **6010**
(Core 6006 · 3D 6007 · Robotics 6008 · Slides 6009 다음).

Core/Theme은 Robotics와 같은 `0.1.0-rc.3`을 소비한다. 알파 부트스트랩 동안은 `vendor/`
tarball을 `file:` 의존성으로 설치하며, 레지스트리 인증이 준비되면 semver 고정으로 전환한다.

```bash
npm install
npm run storybook   # http://127.0.0.1:6010
```

## 외부 참조

채택/미채택 결정은 [docs/references/README.md](./docs/references/README.md)가,
FT Visual Vocabulary 카테고리별 소유 판정과 로드맵은
[docs/references/VISUAL_VOCABULARY_MAP.md](./docs/references/VISUAL_VOCABULARY_MAP.md)가 소유한다.

## 다음 단계

방법론 우선 순서를 따른다 — 컴포넌트 카탈로그 확장보다 워크드 예제가 먼저다.

- 워크드 예제 스토리: 카테고리별로 같은 데이터의 before/after 판을 나란히 —
  절차를 지킨 판은 play 단언으로 검증 (영 기준선·카테고리 수·직접 라벨링).
- 게이트 확장: 스타일 소유권 검사(업스트림 램프 직접 참조 금지 포함), 배포 워크플로.
